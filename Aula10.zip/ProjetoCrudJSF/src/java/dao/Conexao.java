
package dao;

import java.sql.DriverManager;
import java.sql.SQLException;
import com.mysql.jdbc.Connection;

public class Conexao {
    
    private String driver = "com.mysql.jdbc.Driver";
    private String URL = "jdbc:mysql://localhost/ProjetoCrudJSF";
    private String USER = "root";
    private String SENHA = "root";
    private Connection conn;
    
    public Conexao() {
        try {
            Class.forName(driver);
            conn = (Connection) DriverManager.getConnection(URL, USER, SENHA);
        } catch (ClassNotFoundException | SQLException e) { 
        }
    }
    
    public Connection getConn() {
        return conn;
    }
    
    public void fecharConexao() {
        try {
            conn.close();
        } catch (SQLException e) {   
        }
    }
    
}
