
package dao;

import com.mysql.jdbc.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Cliente;

public class ClienteDAO {
    
    private Conexao conexao;
    private Statement stmt;
    private boolean sucesso = false;
    
    public ClienteDAO() {
        conexao = new Conexao();
        try {
            stmt = (Statement) conexao.getConn() .createStatement();
        } catch (SQLException e) {
            
        }
    }
    
    public boolean inserir(Cliente cliente) {
        try {
            stmt.execute("INSERT INTO cliente (nome, telefone) VALUES ('" + cliente.getNome() +"','" + cliente.getTelefone() + "')");
            sucesso = true;
        } catch (SQLException e) {
        } finally {
            conexao.fecharConexao();
        }
        
        return sucesso;
    }
    
    public boolean alterar(Cliente cliente) {
        try {
            stmt.execute("UPDATE cliente SET nome = '" + cliente.getNome() +
                    "', telefone = '" + cliente.getTelefone() +
                    "' WHERE codigo = '" + cliente.getCodigo() + "'");
            sucesso = true;
        } catch (SQLException e) {
        } finally {
            conexao.fecharConexao();
        }
        
        return sucesso;
    }
    
    
    public boolean remover (Cliente cliente) {
        try {
            stmt.execute("DELETE FROM cliente WHERE codigo = '" + cliente.getCodigo() +"'");
            sucesso = true;
        } catch (SQLException e){
        } finally {
            conexao.fecharConexao();
        }
        return sucesso;
    }
    
    public List<Cliente> listar() {
        List<Cliente> clientes = new ArrayList<>();
        try {
            ResultSet rs = stmt.executeQuery("SELECT * FROM cliente ORDER BY nome");
            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setCodigo(rs.getInt("codigo"));
                cliente.setNome(rs.getString("nome"));
                cliente.setTelefone(rs.getString("telefone"));
                
                clientes.add(cliente);
            }
        } catch (SQLException e) {
        } finally {
            conexao.fecharConexao();
        }
        return clientes;
    }
    
}
