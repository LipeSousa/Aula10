
package model;

public class Cliente {
    private int codigo;
    private String nome;
    private String telefone;
    
    public int getCodigo() {
        return codigo;
    }
    
    public void setCodigo (int Codigo) {
        this.codigo = codigo;
    }
    
    public String getNome() {
        return nome;
    }
    
    public void setNome (String nome) {
        this.nome = nome;
    }
    
    public String getTelefone() {
        return telefone;
    }
    
    public void setTelefone (String Telefone) {
        this.telefone = telefone;
    }
    
}
